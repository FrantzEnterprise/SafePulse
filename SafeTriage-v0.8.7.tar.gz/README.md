# SafeTriage — Safe Failure Prediction App

## Overview
SafeTriage (formerly SafePulse) is a diagnostic triage tool for safe technicians. Customers fill out a step-by-step form about their safe issue, and the app generates a risk score, possible causes, remedies, and a full technician report with estimated service fees.

Built for **Frantz Locksmith Service** by Safe Technician.

## Live Demo
**GitHub Pages:** https://frantzenterprise.github.io/SafePulse/

## Development Setup

```bash
npm install
npm run dev
```

## Production Build

```bash
npm run build
# Output in dist/
```

Deploy the `dist/` folder to any static host (GitHub Pages, Netlify, etc.).

## Admin Panel
Click the ⚙ Admin button in the header to access:
- **Branding** — Company name, phone, email, colors, fonts
- **Company Info** — Address, tagline
- **Service Area** — Shop address, base fee, mileage rates
- **Features** — Toggle photo upload, map calculator, battery popup, Q&A section
- **Q&A** — Toggle and URL for external knowledge base
- **Symptoms** — Full CRUD editor for symptom categories, items, causes, remedies, parts; import/export/reset
- **Integrations** — Google Maps API key
- **Export** — Download config

## File Structure

```
SafePulse/
├── src/
│   ├── SafePulseDemo.jsx    # Main app (952 lines) — form, triage, results, modals
│   ├── AdminPanel.jsx       # Admin dashboard (453 lines)
│   ├── SymptomEditor.jsx    # Symptom CRUD editor
│   ├── style.css            # Tailwind CSS classes + brand variables
│   ├── config.json          # Company config defaults
│   ├── useConfig.js         # Config loader hook
│   └── components/ui/
│       ├── button.jsx
│       └── card.jsx
├── dist/                    # Built static files (deploy this)
├── package.json
├── vite.config.js
└── index.html
```

## 5-Step Form Flow
1. **Contact Information** — Name, phone, email (optional)
2. **Safe Details** — Brand, lock type, open/closed, service age
3. **Symptoms & Photos** — Select symptoms by category, upload photos
4. **Service Area & Quote** — Enter miles, calculate trip fee, map modal
5. **Service & Cost Framework** — Trip fee, standard/high security labor ranges

## Risk Scoring
- 0–24: Low — Simple troubleshooting
- 25–49: Medium — Monitor symptoms
- 50–74: High — Schedule service
- 75–100: Urgent — Stop attempts, call technician

Scoring factors: symptom points + safe-closed penalty (+20) + age penalty (+15 for 5+ yrs). Caps at 100.

## Technician Dispatch
When customer clicks "Still Needs Tech":
1. **SMS** sent to company phone with full technician report
2. **Email** auto-reply sent to customer (if they entered email) with BCC to company

## Contact
**Frantz Locksmith Service**  
(916) 534-4900  
frantzlocksmith@hotmail.com  
West Sacramento, CA 95691  
CA LCO 4160

## Version
v0.8.7 — Step 4 Service Area & Quote with map modal synced miles
